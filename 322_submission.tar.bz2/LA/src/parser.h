#pragma once

#include <la.h>

#include <stdio.h>
#include <vector>
#include <string>
#include <cstddef>

namespace LA {


    
      
   /* ------------------------------------------------------------------
     *  Tokenizer — splits a string on whitespace and hands out tokens
     *  one at a time. Replaces all the manual pos++ / find / substr
     *  scaffolding the actions used to do by hand.
     * ------------------------------------------------------------------ */
    class Tokenizer {
        std::vector<std::string> tokens;
        size_t pos = 0;

        public:
            explicit Tokenizer(const std::string& s) {
                std::string cur;
                auto flush = [&]() {
                    if (!cur.empty()) { tokens.push_back(cur); cur.clear(); }
                };

                auto isPunct = [](char c) {
                    return c == '(' || c == ')' || c == '{' || c == '}' || c == ','
                        || c == '[' || c == ']';   // LA: array index / int64[] type
                };

                for (size_t i = 0; i < s.size(); ++i) {
                    char c = s[i];
                    char n1 = (i + 1 < s.size()) ? s[i + 1] : '\0';

                    // whitespace
                    if (c == ' ' || c == '\t' || c == '\n' || c == '\r') {
                        flush();
                        continue;
                    }

                    // single-char punctuation
                    if (isPunct(c)) {
                        flush();
                        tokens.push_back(std::string(1, c));
                        continue;
                    }

                    // two-char operators: <-, <<, >>, <=, >=
                    if (c == '<' && n1 == '-') { flush(); tokens.push_back("<-"); ++i; continue; }
                    if (c == '<' && n1 == '<') { flush(); tokens.push_back("<<"); ++i; continue; }
                    if (c == '>' && n1 == '>') { flush(); tokens.push_back(">>"); ++i; continue; }
                    if (c == '<' && n1 == '=') { flush(); tokens.push_back("<="); ++i; continue; }
                    if (c == '>' && n1 == '=') { flush(); tokens.push_back(">="); ++i; continue; }

                    // single-char operators that always stand alone: <, >, =, +, *, &
                    // ('-' is special — could be op OR start of negative number OR inside 'tuple-error')
                    if (c == '<' || c == '>' || c == '=' || c == '+' || c == '*' || c == '&') {
                        flush();
                        tokens.push_back(std::string(1, c));
                        continue;
                    }

                    // '-' handling: problem caused due to improper spacing. 
                   
                    if (c == '-') {
                        // tuple-error / tensor-error: cur holds the prefix
                        if (cur == "tuple" || cur == "tensor") { cur += c; continue; }

                        // Decide: is this a binary subtract or a unary minus?
                        // It's a binary subtract if the previous emitted token is a value-like thing.
                        bool prev_is_value = false;
                        if (!cur.empty()) {
                            prev_is_value = true;  // mid-identifier, e.g. "%val" being built
                        } else if (!tokens.empty()) {
                            char pc = tokens.back()[0];
                            prev_is_value = (pc == '%' || pc == '@' || pc == ':' || pc == ')'
                                            || pc == ']'    // LA: closing array index is value-like
                                            || (pc >= '0' && pc <= '9'));
                        }

                        flush();
                        if (prev_is_value) {
                            tokens.push_back("-");                                // binary subtract
                        } else if (n1 >= '0' && n1 <= '9') {
                            cur += c;                                             // negative literal
                        } else {
                            tokens.push_back("-");                                // standalone op (rare)
                        }
                        continue;
                    }
                    cur += c;
                }
                flush();
            }

            // get next token and advance
            std::string next() {
                if (pos >= tokens.size())
                    throw std::runtime_error("tokenizer: no more tokens");
                return tokens[pos++];
            }

            // look without advancing
            const std::string& peek(size_t offset = 0) const {
                if (pos + offset >= tokens.size())
                    throw std::runtime_error("tokenizer: peek past end");
                return tokens[pos + offset];
            }

            bool done() const { return pos >= tokens.size(); }
            size_t remaining() const { return tokens.size() - pos; }

            // consume and verify (useful for "mem", "<-", etc.)
            void expect(const std::string& s) {
                std::string t = next();
                if (t != s)
                    throw std::runtime_error("tokenizer: expected '" + s + "' got '" + t + "'");
            }
        };





        LA::Program parse_file(const char* fileName);
}