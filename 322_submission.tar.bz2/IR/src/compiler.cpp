#include <algorithm>
#include <assert.h>
#include <cctype>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <iterator>
#include <set>
#include <stdint.h>
#include <string>
#include <unistd.h>
#include <utility>
#include <vector>
#include <parser.h>
#include <generator.h>
// #include <generator.h>


// https://en.wikipedia.org/wiki/Value_numbering : suggested optimizations to add:
// - local value numbering (eliminate redundant computations within a basic block)
// - global value numbering (eliminate redundant computations across basic blocks, using SSA form)
// - dead code elimination (remove instructions whose results are never used)


#include <utils.h>

void print_help(char *progName) {
  std::cerr << "Usage: " << progName << " [-v] [-g 0|1] [-O 0|1|2] SOURCE"
            << std::endl;
  return;
}

int main(int argc, char **argv) {
  auto enable_code_generator = true;
  int32_t optLevel = 3;

  /*
   * Check the compiler arguments.
   */
  Utils::verbose = false;
  if (argc < 2) {
    print_help(argv[0]);
    return 1;
  }
  int32_t opt;
  while ((opt = getopt(argc, argv, "vg:O:")) != -1) {
    switch (opt) {
    case 'O':
      optLevel = strtoul(optarg, NULL, 0);
      break;

    case 'g':
      enable_code_generator = (strtoul(optarg, NULL, 0) == 0) ? false : true;
      break;

    case 'v':
      Utils::verbose = true;
      break;

    default:
      print_help(argv[0]);
      return 1;
    }
  }

  /*
   * Parse the input file.
   */
  char *fileName = argv[optind];

  auto program = IR::parse_file(fileName);



  /*
   * Print the program.
   */
  if (Utils::verbose) {
    // TODO
  }

  for (auto& f : program.functions){
    f.build_traces();
  }

    // std::cerr << program.to_string();
  /*
   * Generate the code.
   */
  if (enable_code_generator) {
    IR::generate_code(program);
    
  }

  return 0;
}